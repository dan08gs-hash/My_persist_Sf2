# Workflow completo e revisado — SF2 Player 0.9.5

## 1. Objetivo do aplicativo

Aplicativo Android nativo (Kotlin + Compose + JNI/FluidSynth) para:

- Importar arquivos SoundFont (`.sf2`) e guardá-los de forma **permanente** no armazenamento privado do app.
- Atribuir a cada uma de **5 faixas** um SoundFont e um preset (timbre) diferentes.
- Tocar via **controlador MIDI USB** (sem teclado virtual).
- Controlar volume master, volumes por faixa, sustain, oitava, transposição, reverb e chorus.
- Salvar/carregar presets nomeados e restaurar automaticamente a sessão anterior.

## 2. Arquitetura

```
MainActivity (Compose UI)
    │
    ├── NativeSynth (Kotlin)
    │       │  loadLibrary("sf2native")
    │       │  AudioTrack (LOW_LATENCY, PCM 16-bit stereo)
    │       │  Thread dedicada de render (MAX_PRIORITY)
    │       ▼
    └── sf2native.c (JNI)
            │  pthread_mutex
            ▼
        FluidSynth (libfluidsynth.so)
```

### Fluxo de áudio (baixa latência)

1. Device sample rate e frames-per-buffer são lidos de `AudioManager`.
2. `AudioTrack` é criado com `PERFORMANCE_MODE_LOW_LATENCY`.
3. Thread de áudio chama `renderNative` → `fluid_synth_write_float` (buffers na pilha).
4. Conversão float → int16 com soft-clip e `AudioTrack.write(WRITE_BLOCKING)`.
5. Parada segura: `running=false` → pause/flush/stop → join da thread → release.

### Persistência (correção do bug reportado)

| Dado | Onde fica | Quando é gravado | Quando é lido |
|------|-----------|------------------|---------------|
| Arquivos `.sf2` | `filesDir/soundfonts/UUID--nome.sf2` | Na importação | No `LaunchedEffect` inicial |
| Índice da biblioteca (id + nome) | SharedPreferences `library_index` | Import / exclusão / dispose | No start |
| Estado da sessão (faixas, volumes, efeitos, CCs…) | SharedPreferences `session_state` | A cada mudança relevante + dispose | No start |
| Presets nomeados | SharedPreferences `presets` | Botão “Salvar preset” | No start (lista) |

**Por que os arquivos “sumiam” antes:**  
A restauração dependia apenas do `listFiles()` do diretório. Sem um índice estável e sem salvar o estado das faixas, qualquer falha silenciosa no `loadNative` (ou ordem diferente) fazia a UI parecer vazia. Agora:

1. O índice é a fonte de verdade da ordem e dos nomes de exibição.
2. Arquivos órfãos no disco ainda são recuperados.
3. Se um arquivo não carregar, ele simplesmente não entra na lista (não derruba o resto).
4. As faixas e volumes voltam exatamente como estavam.

## 3. Ciclo de vida típico

1. **Primeira abertura**  
   - Biblioteca vazia → usuário importa SF2 → arquivo copiado + índice + sessão gravados → áudio inicia.

2. **Uso normal**  
   - Mudanças de faixa/volume/efeitos → `persistSession()` automático.  
   - MIDI → note on/off / CC → UI atualizada na main thread.

3. **Fechar o app**  
   - `DisposableEffect` grava sessão + índice e chama `engine.close()`.

4. **Reabrir**  
   - Lê índice → carrega cada SF2 do disco → aplica sessão → `ensureAudioRunning()` → pronto para tocar.

## 4. Como compilar (passo a passo)

1. Extraia o ZIP.
2. Coloque `libfluidsynth.so` (arm64-v8a) em  
   `app/src/main/jniLibs/arm64-v8a/`.
3. Coloque os headers FluidSynth em  
   `app/src/main/cpp/fluidsynth/include/`.
4. Abra a pasta `SF2Player_Projeto` no Android Studio (ou use o workflow GitHub Actions existente).
5. Sync Gradle → Build → Run em dispositivo arm64 (min API 26).
6. Teste: importe 1–2 SF2, atribua às faixas, feche o app completamente, reabra e verifique se a biblioteca e as faixas voltaram.

## 5. Checklist de validação (estabilidade e latência)

- [ ] Importar SF2 → aparece na Biblioteca e nas Faixas.
- [ ] Fechar app (Force stop) → reabrir → arquivos e faixas presentes.
- [ ] Tocar notas via MIDI USB sem clicks/underruns em buffer 192.
- [ ] Mudar buffer para 128 e 512 sem crash.
- [ ] Rotacionar tela (paisagem/retrato) → faders mudam de orientação sem reiniciar o áudio.
- [ ] Excluir SF2 não usado → some do índice e do disco.
- [ ] Salvar/carregar preset nomeado.
- [ ] Reverb/chorus on/off sem estalos.

## 6. Limitações conhecidas

- Apenas ABI **arm64-v8a**.
- FluidSynth precisa ser fornecido pelo integrador (LGPL).
- Entrada de notas somente via MIDI (teclado virtual removido de propósito).
- Um único sintetizador FluidSynth compartilha todos os SF2 carregados (comportamento desejado).

## 7. Arquivos principais alterados nesta versão

- `MainActivity.kt` — persistência completa (índice + sessão), restauração robusta.
- `NativeSynth.kt` — sample-rate do dispositivo, buffer adaptativo, `ensureAudioRunning`, mais proteção.
- `sf2native.c` — interpolação de 7ª ordem, threadsafe-api, mesma política de stack buffers.
- `app/build.gradle.kts` — versionCode 11 / versionName 0.9.5-stable-persist-arm64.
- README e este WORKFLOW.

---

**Versão entregue:** 0.9.5-stable-persist-arm64  
**Data de revisão:** 2026-10-17
