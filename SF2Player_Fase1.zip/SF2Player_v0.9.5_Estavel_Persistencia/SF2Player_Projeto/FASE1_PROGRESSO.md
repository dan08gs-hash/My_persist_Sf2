# SF2 Player — Fase 1, incremento 1

Base: v0.9.5 Estavel Persistencia (ZIP recebido).

Alterações:
- IDs estáveis track-1 a track-5 no modelo TrackState e no JSON persistido.
- Leitura retrocompatível: IDs são derivados da posição mesmo para sessões antigas.
- ParameterRegistry.kt: descritores declarativos para master.volume e volume/ativação de 5 faixas.
- Nenhuma alteração no motor AudioTrack, FluidSynth, MIDI, layout ou workflow.

Não implementado: MIDI Learn, curvas por faixa, nova UI, roteamento genérico de parâmetros.
Não validado: compilação Gradle/APK e testes em dispositivo.
Próximo passo: conectar controles atuais ao registro, com testes de regressão e build GitHub Actions.
