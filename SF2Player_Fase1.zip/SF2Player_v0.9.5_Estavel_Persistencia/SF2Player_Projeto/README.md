# SF2 Player 0.9.5 — Estável + Persistência completa

Player Android de SoundFont (`.sf2`) baseado em FluidSynth, com biblioteca privada de múltiplos SF2, 5 faixas independentes, mesa de som adaptativa e entrada MIDI USB.

## O que mudou em relação à 0.9.4

### Persistência (correção principal)
- **Índice da biblioteca** gravado em `SharedPreferences` (`library_index`).
- **Arquivos SF2** continuam em `filesDir/soundfonts/` (cópia permanente).
- **Estado da sessão** (faixas, volumes, efeitos, buffer, oitava, CCs MIDI, etc.) salvo automaticamente e restaurado ao reabrir o app.
- Ao fechar e abrir de novo, os SoundFonts e a configuração das faixas voltam.

### Estabilidade / anti-crash
- Ciclo de vida do `AudioTrack` sincronizado (não libera enquanto a thread ainda escreve).
- Impede segunda thread de render enquanto a anterior está viva.
- Tratamento de falhas de inicialização/escrita de áudio.
- Try/catch em todas as chamadas nativas e no caminho de áudio.
- Buffers de render em pilha (máx. 1024 frames) — zero malloc no callback.

### Áudio de baixa latência e qualidade
- Sample rate preferido do dispositivo (`PROPERTY_OUTPUT_SAMPLE_RATE`).
- Buffer inicial baseado em `PROPERTY_OUTPUT_FRAMES_PER_BUFFER` (tipicamente 128–256).
- `PERFORMANCE_MODE_LOW_LATENCY` + modo stream.
- Interpolação FluidSynth de 7ª ordem.
- Polyphony 256, efeitos reverb/chorus configuráveis.

### Interface
- Aba Faixas: faders verticais em paisagem, horizontais em retrato.
- Teclado virtual removido (entrada via MIDI externo).

## Dependências nativas (obrigatórias para compilar)

O pacote de código **não inclui** o binário FluidSynth. Você precisa:

1. Colocar `libfluidsynth.so` (e dependências, se houver) em:
   ```
   app/src/main/jniLibs/arm64-v8a/
   ```
2. Colocar os headers públicos de FluidSynth em:
   ```
   app/src/main/cpp/fluidsynth/include/
   ```
   (pelo menos `fluidsynth.h` e os includes que ele puxa)

O `CMakeLists.txt` já aponta para esses caminhos.

## Compilação

- Android Studio (recomendado) ou GitHub Actions com NDK 27+.
- ABI: **arm64-v8a** apenas.
- minSdk 26, targetSdk 35, compileSdk 36.
- Kotlin 2.2 + Compose BOM 2025.10.

## Licença

FluidSynth: LGPL-2.1-or-later. Preserve os avisos de licença ao redistribuir.
