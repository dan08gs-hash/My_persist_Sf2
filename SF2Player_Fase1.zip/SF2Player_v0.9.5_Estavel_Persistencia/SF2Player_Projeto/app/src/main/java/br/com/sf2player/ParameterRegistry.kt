package br.com.sf2player

/** Stable identifiers for mixer parameters; no audio-engine side effects. */
internal enum class ParameterKind { CONTINUOUS, TOGGLE, DISCRETE }

internal data class ParameterDescriptor(
    val id: String,
    val label: String,
    val kind: ParameterKind,
    val minimum: Float,
    val maximum: Float,
    val defaultValue: Float,
    val realtimeSafe: Boolean = true
) {
    init {
        require(id.isNotBlank() && minimum <= maximum)
        require(defaultValue in minimum..maximum)
    }

    fun normalize(value: Float): Float = value.coerceIn(minimum, maximum)
}

/** Declarative metadata only. Features are enabled after actual engine support is verified. */
internal object ParameterRegistry {
    val masterVolume = ParameterDescriptor("master.volume", "Volume master", ParameterKind.CONTINUOUS, 0f, 1f, 0.8f)

    fun trackVolume(trackId: String): ParameterDescriptor {
        require(Regex("track-[1-5]").matches(trackId))
        return ParameterDescriptor("$trackId.volume", "Volume da faixa", ParameterKind.CONTINUOUS, 0f, 1f, 0.8f)
    }

    fun trackEnabled(trackId: String): ParameterDescriptor {
        require(Regex("track-[1-5]").matches(trackId))
        return ParameterDescriptor("$trackId.enabled", "Faixa ativa", ParameterKind.TOGGLE, 0f, 1f, 1f)
    }

    val implemented: List<ParameterDescriptor> = listOf(masterVolume) + (1..5).flatMap {
        listOf(trackVolume("track-$it"), trackEnabled("track-$it"))
    }
}
