package br.com.sf2player

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.pow

/**
 * Native FluidSynth engine with low-latency AudioTrack output.
 * Designed for stability: single audio thread, synchronized lifecycle,
 * no allocations in the real-time path, and safe stop/start.
 */
class NativeSynth(context: Context? = null) {
    companion object {
        init {
            System.loadLibrary("sf2native")
        }
    }

    // Returns FluidSynth's internal SoundFont ID, or -1 on failure.
    private external fun loadNative(path: String, rate: Int): Int
    private external fun noteOnNative(channel: Int, key: Int, velocity: Int)
    private external fun noteOffNative(channel: Int, key: Int)
    private external fun volumeNative(volume: Float)
    private external fun trackVolumeNative(channel: Int, volume: Float)
    private external fun renderNative(buffer: ShortArray, frames: Int)
    private external fun closeNative()
    private external fun presetCountNative(soundFontNativeId: Int): Int
    private external fun presetNameNative(soundFontNativeId: Int, index: Int): String
    private external fun selectPresetNative(channel: Int, soundFontNativeId: Int, index: Int): Boolean
    private external fun sustainNative(channel: Int, enabled: Boolean)
    private external fun setEffectsNative(reverb: Boolean, reverbLevel: Float, chorus: Boolean, chorusLevel: Float)

    private var audioTrack: AudioTrack? = null
    private val running = AtomicBoolean(false)
    private val audioLifecycleLock = Any()
    @Volatile private var audioThread: Thread? = null
    private val noteStateLock = Any()
    private val sustainDown = BooleanArray(16)
    private val deferredNoteOff = Array(16) { mutableSetOf<Int>() }

    @Volatile private var sampleRate = 48000
    @Volatile private var bufferFrames = 192
    @Volatile var velocityCurve = 1.0f
    @Volatile var loaded = false; private set
    @Volatile var status = "Importe um SoundFont"; private set

    init {
        // Prefer the device's native sample rate for lowest latency and best quality.
        if (context != null) {
            try {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val rateStr = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)
                val rate = rateStr?.toIntOrNull()
                if (rate != null && rate in 22050..96000) {
                    sampleRate = rate
                }
                val framesStr = am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)
                val deviceFrames = framesStr?.toIntOrNull()
                if (deviceFrames != null && deviceFrames in 64..1024) {
                    // Use a small multiple of the device period for low latency without underruns.
                    bufferFrames = (deviceFrames * 2).coerceIn(128, 512)
                }
            } catch (_: Exception) {
                // Keep defaults.
            }
        }
    }

    /** Adds a SoundFont to the existing synth; does not remove previously imported fonts. */
    @Synchronized
    fun loadSoundFont(file: File, rate: Int = sampleRate): Int {
        if (!file.isFile || file.length() <= 0L) {
            status = "Arquivo SoundFont inválido"
            return -1
        }
        val wasLoaded = loaded
        sampleRate = rate
        val id = try {
            loadNative(file.absolutePath, rate)
        } catch (e: Exception) {
            status = "Erro nativo ao carregar: ${e.message}"
            return -1
        }
        if (id < 0) {
            status = "Não foi possível ler ${file.name}"
            return -1
        }
        loaded = true
        status = "SoundFont carregado: ${file.name}"
        if (!wasLoaded) {
            synchronized(noteStateLock) {
                for (ch in 0 until 16) {
                    sustainDown[ch] = false
                    deferredNoteOff[ch].clear()
                }
            }
            setVolume(0.8f)
            startAudio()
        }
        return id
    }

    // Compatibility wrapper for older call sites.
    fun load(file: File, rate: Int = sampleRate): Boolean = loadSoundFont(file, rate) >= 0

    fun presetCount(soundFontNativeId: Int): Int =
        if (loaded && soundFontNativeId >= 0) {
            try {
                presetCountNative(soundFontNativeId).coerceAtLeast(0)
            } catch (_: Exception) {
                0
            }
        } else 0

    fun presetName(index: Int, soundFontNativeId: Int): String =
        if (loaded && index in 0 until presetCount(soundFontNativeId)) {
            try {
                presetNameNative(soundFontNativeId, index)
            } catch (_: Exception) {
                "Instrumento ${index + 1}"
            }
        } else "Instrumento ${index + 1}"

    fun selectPreset(index: Int, channel: Int = 0, soundFontNativeId: Int): Boolean =
        loaded && channel in 0..15 && soundFontNativeId >= 0 && try {
            selectPresetNative(channel, soundFontNativeId, index)
        } catch (_: Exception) {
            false
        }

    fun setSustain(enabled: Boolean, channel: Int = 0) {
        if (!loaded) return
        val ch = channel.coerceIn(0, 15)
        synchronized(noteStateLock) {
            if (sustainDown[ch] == enabled) return
            sustainDown[ch] = enabled
            try {
                sustainNative(ch, enabled)
            } catch (_: Exception) {
            }
            if (!enabled) {
                deferredNoteOff[ch].forEach {
                    try {
                        noteOffNative(ch, it)
                    } catch (_: Exception) {
                    }
                }
                deferredNoteOff[ch].clear()
            }
        }
    }

    @Synchronized
    fun setBufferFrames(frames: Int) {
        val f = frames.coerceIn(128, 1024)
        if (bufferFrames == f) return
        bufferFrames = f
        if (loaded) {
            stopAudio()
            startAudio()
        }
    }

    fun getBufferFrames() = bufferFrames
    fun getSampleRate() = sampleRate

    fun setEffects(reverb: Boolean, reverbLevel: Float, chorus: Boolean, chorusLevel: Float) {
        try {
            setEffectsNative(reverb, reverbLevel, chorus, chorusLevel)
        } catch (_: Exception) {
        }
    }

    private fun startAudio() = synchronized(audioLifecycleLock) {
        if (!loaded || running.get() || audioThread?.isAlive == true) return@synchronized

        val frames = bufferFrames
        val minBytes = try {
            AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
        } catch (_: Exception) {
            -1
        }
        if (minBytes <= 0) {
            status = "Formato de áudio não suportado pelo dispositivo"
            return@synchronized
        }

        // Size: at least 2–4 periods of our block to absorb scheduling jitter while staying low-latency.
        val size = maxOf(minBytes, frames * 4 * 2) // frames * stereo * sizeof(short) * 2 periods
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(size)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
        } catch (e: Exception) {
            status = "Falha ao iniciar áudio: ${e.message ?: "erro desconhecido"}"
            return@synchronized
        }

        if (track.state != AudioTrack.STATE_INITIALIZED) {
            try {
                track.release()
            } catch (_: Exception) {
            }
            status = "Não foi possível inicializar a saída de áudio"
            return@synchronized
        }

        audioTrack = track
        running.set(true)
        try {
            track.play()
        } catch (e: Exception) {
            running.set(false)
            audioTrack = null
            try {
                track.release()
            } catch (_: Exception) {
            }
            status = "Falha ao iniciar reprodução: ${e.message ?: "erro desconhecido"}"
            return@synchronized
        }

        val worker = Thread({
            val buffer = ShortArray(frames * 2)
            try {
                while (running.get() && !Thread.currentThread().isInterrupted) {
                    try {
                        renderNative(buffer, frames)
                    } catch (_: Exception) {
                        // Keep the stream alive even if a single render fails.
                        buffer.fill(0)
                    }
                    var offset = 0
                    while (offset < buffer.size && running.get()) {
                        val wrote = try {
                            track.write(buffer, offset, buffer.size - offset, AudioTrack.WRITE_BLOCKING)
                        } catch (_: IllegalStateException) {
                            break
                        } catch (_: Exception) {
                            break
                        }
                        if (wrote < 0) break
                        if (wrote == 0) {
                            Thread.yield()
                        } else {
                            offset += wrote
                        }
                    }
                }
            } catch (_: Exception) {
                // An audio-device transition must not crash the application.
            } finally {
                running.set(false)
            }
        }, "FluidSynth-Audio")
        worker.priority = Thread.MAX_PRIORITY
        audioThread = worker
        worker.start()
        status = "Áudio ativo • ${sampleRate} Hz • ${frames} frames"
    }

    fun noteOn(key: Int, velocity: Int = 100, channel: Int = 0) {
        if (!loaded) return
        val ch = channel.coerceIn(0, 15)
        val k = key.coerceIn(0, 127)
        val v = (velocity.coerceIn(1, 127) / 127.0)
            .pow(velocityCurve.coerceIn(0.5f, 2.0f).toDouble())
        synchronized(noteStateLock) {
            deferredNoteOff[ch].remove(k)
            try {
                noteOnNative(ch, k, (v * 127.0).toInt().coerceIn(1, 127))
            } catch (_: Exception) {
            }
        }
    }

    fun noteOff(key: Int, channel: Int = 0) {
        if (!loaded) return
        val ch = channel.coerceIn(0, 15)
        val k = key.coerceIn(0, 127)
        synchronized(noteStateLock) {
            if (sustainDown[ch]) {
                deferredNoteOff[ch].add(k)
            } else {
                try {
                    noteOffNative(ch, k)
                } catch (_: Exception) {
                }
            }
        }
    }

    fun setVolume(v: Float) {
        try {
            volumeNative(v.coerceIn(0f, 1f))
        } catch (_: Exception) {
        }
    }

    fun setTrackVolume(channel: Int, v: Float) {
        if (loaded) {
            try {
                trackVolumeNative(channel.coerceIn(0, 15), v.coerceIn(0f, 1f))
            } catch (_: Exception) {
            }
        }
    }

    fun stopAudio() {
        val track: AudioTrack?
        val worker: Thread?
        synchronized(audioLifecycleLock) {
            running.set(false)
            track = audioTrack
            worker = audioThread
            audioTrack = null
            try {
                track?.pause()
            } catch (_: Exception) {
            }
            try {
                track?.flush()
            } catch (_: Exception) {
            }
            try {
                track?.stop()
            } catch (_: Exception) {
            }
            worker?.interrupt()
        }

        if (worker != null && worker !== Thread.currentThread()) {
            try {
                worker.join(750)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
            if (worker.isAlive) {
                try {
                    worker.join(750)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
        }
        try {
            track?.release()
        } catch (_: Exception) {
        }
        synchronized(audioLifecycleLock) {
            if (audioThread === worker && (worker == null || !worker.isAlive)) {
                audioThread = null
            }
        }
    }

    /** Restart the audio engine if it was stopped (e.g. after restore). */
    @Synchronized
    fun ensureAudioRunning() {
        if (loaded && !running.get()) {
            startAudio()
        }
    }

    @Synchronized
    fun close() {
        stopAudio()
        synchronized(noteStateLock) {
            for (ch in 0 until 16) {
                sustainDown[ch] = false
                deferredNoteOff[ch].clear()
            }
        }
        try {
            closeNative()
        } catch (_: Exception) {
        }
        loaded = false
        status = "Motor de áudio encerrado"
    }
}
