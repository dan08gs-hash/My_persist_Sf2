package br.com.sf2player

import android.content.Context
import android.content.res.Configuration
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiReceiver
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

private val bg = Color(0xFF0D1117)
private val panel = Color(0xFF171F2B)
private val cyan = Color(0xFF38BDF8)
private val white = Color(0xFFF8FAFC)
private val muted = Color(0xFF9CA3AF)

private data class SoundFontItem(val id: String, val name: String, val file: File, val nativeId: Int)

private data class TrackState(
    val name: String,
    val id: String = "",
    val soundFontId: String = "",
    val presetIndex: Int = 0,
    val volume: Float = 0.8f,
    val enabled: Boolean = true
)

private data class SavedPreset(val name: String, val json: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 17, 23)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = cyan,
                    background = bg,
                    surface = panel,
                    onBackground = white,
                    onSurface = white
                )
            ) {
                PlayerScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { NativeSynth(context) }

    var sf2Name by remember { mutableStateOf("Biblioteca vazia") }
    var library by remember { mutableStateOf<List<SoundFontItem>>(emptyList()) }
    val libraryDir = remember { File(context.filesDir, "soundfonts").apply { mkdirs() } }
    var status by remember { mutableStateOf("Escolha um arquivo .sf2 para começar") }
    var loaded by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(0.8f) }
    var octave by remember { mutableIntStateOf(0) }
    var transpose by remember { mutableIntStateOf(0) }
    var sustain by remember { mutableStateOf(false) }
    var bufferFrames by remember { mutableIntStateOf(engine.getBufferFrames()) }
    var velocityCurve by remember { mutableFloatStateOf(1.0f) }
    var reverbEnabled by remember { mutableStateOf(true) }
    var reverbLevel by remember { mutableFloatStateOf(0.35f) }
    var chorusEnabled by remember { mutableStateOf(true) }
    var chorusLevel by remember { mutableFloatStateOf(0.25f) }
    var tab by remember { mutableStateOf("Tocar") }
    var midiStatus by remember { mutableStateOf("MIDI USB: desconectado") }
    val midiDevices = remember { mutableStateListOf<MidiDevice>() }
    val midiNames = remember { mutableStateListOf<String>() }
    var midiAvailable by remember { mutableStateOf<List<MidiDeviceInfo>>(emptyList()) }
    var ccMaster by remember { mutableStateOf("7") }
    var ccSustain by remember { mutableStateOf("64") }
    var ccTrack1 by remember { mutableStateOf("20") }
    var ccTrack2 by remember { mutableStateOf("21") }
    var ccTrack3 by remember { mutableStateOf("22") }
    var ccTrack4 by remember { mutableStateOf("23") }
    var ccTrack5 by remember { mutableStateOf("24") }
    var tracks by remember {
        mutableStateOf(List(5) { i -> TrackState("Faixa ${i + 1}", id = "track-${i + 1}", volume = 0.8f, enabled = i == 0) })
    }
    var newPresetName by remember { mutableStateOf("") }
    var savedPresets by remember { mutableStateOf(readSavedPresets(context)) }
    var presetMessage by remember { mutableStateOf("Presets ficam salvos neste celular") }
    var sessionRestored by remember { mutableStateOf(false) }

    fun persistLibraryIndex(items: List<SoundFontItem>) {
        writeLibraryIndex(context, items.map { it.id to it.name })
    }

    fun persistSession() {
        writeSessionState(
            context,
            SessionState(
                volume = volume,
                octave = octave,
                transpose = transpose,
                sustain = sustain,
                bufferFrames = bufferFrames,
                velocityCurve = velocityCurve,
                reverbEnabled = reverbEnabled,
                reverbLevel = reverbLevel,
                chorusEnabled = chorusEnabled,
                chorusLevel = chorusLevel,
                tracks = tracks,
                ccMaster = ccMaster,
                ccSustain = ccSustain,
                ccTrack1 = ccTrack1,
                ccTrack2 = ccTrack2,
                ccTrack3 = ccTrack3,
                ccTrack4 = ccTrack4,
                ccTrack5 = ccTrack5
            )
        )
    }

    fun updateTrack(index: Int, newTrack: TrackState) {
        tracks = tracks.mapIndexed { i, old -> if (i == index) newTrack else old }
        persistSession()
    }

    fun applyTrackSettings(newTracks: List<TrackState>) {
        tracks = newTracks.take(5).mapIndexed { i, t ->
            val font = library.firstOrNull { it.id == t.soundFontId }
            val maxPreset = (font?.let { engine.presetCount(it.nativeId) } ?: 1) - 1
            val fixed = t.copy(
                name = "Faixa ${i + 1}",
                id = "track-${i + 1}",
                presetIndex = t.presetIndex.coerceIn(0, maxPreset.coerceAtLeast(0)),
                volume = t.volume.coerceIn(0f, 1f)
            )
            if (loaded && font != null) {
                engine.selectPreset(fixed.presetIndex, i, font.nativeId)
                engine.setTrackVolume(i, if (fixed.enabled) fixed.volume else 0f)
            }
            fixed
        } + List((5 - newTracks.size).coerceAtLeast(0)) { i ->
            TrackState("Faixa ${newTracks.size + i + 1}")
        }
        persistSession()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            status = "Importando SoundFont para a biblioteca…"
            scope.launch {
                try {
                    val item = withContext(Dispatchers.IO) {
                        val original = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')
                            ?.takeIf { it.isNotBlank() } ?: "SoundFont.sf2"
                        val safeName = original.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(76)
                        val clean = if (safeName.endsWith(".sf2", ignoreCase = true)) safeName else "$safeName.sf2"
                        val file = File(libraryDir, "${UUID.randomUUID()}--$clean")
                        context.contentResolver.openInputStream(uri).use { input ->
                            requireNotNull(input) { "Não foi possível abrir o arquivo" }.use { stream ->
                                file.outputStream().use { output -> stream.copyTo(output) }
                            }
                        }
                        // Ensure file is fully written to disk before loading.
                        file.setReadable(true)
                        val nativeId = engine.loadSoundFont(file)
                        if (nativeId < 0) {
                            file.delete()
                            throw IllegalArgumentException("O arquivo não pôde ser carregado pelo FluidSynth.")
                        }
                        SoundFontItem(file.name, clean, file, nativeId)
                    }
                    library = library + item
                    persistLibraryIndex(library)
                    loaded = true
                    sf2Name = item.name
                    status = "SoundFont '${item.name}' importado e armazenado na biblioteca."
                    tracks = tracks.mapIndexed { i, t ->
                        if (t.soundFontId.isBlank()) {
                            val count = engine.presetCount(item.nativeId)
                            val preset = if (count > 0) i.coerceAtMost(count - 1) else 0
                            engine.selectPreset(preset, i, item.nativeId)
                            engine.setTrackVolume(i, if (t.enabled) t.volume else 0f)
                            t.copy(soundFontId = item.id, presetIndex = preset)
                        } else t
                    }
                    persistSession()
                } catch (e: Exception) {
                    status = "Erro ao importar SF2: ${e.message}"
                }
            }
        }
    }

    // Restore library + session on first composition.
    LaunchedEffect(Unit) {
        if (sessionRestored) return@LaunchedEffect
        status = "Restaurando biblioteca…"
        val index = withContext(Dispatchers.IO) { readLibraryIndex(context) }
        val existingFiles = withContext(Dispatchers.IO) {
            libraryDir.listFiles()?.filter { it.isFile && it.name.endsWith(".sf2", ignoreCase = true) }
                ?.associateBy { it.name } ?: emptyMap()
        }
        val restored = mutableListOf<SoundFontItem>()
        // Prefer the persisted index order; fall back to directory scan.
        val idsToLoad = if (index.isNotEmpty()) {
            index.map { it.first }
        } else {
            existingFiles.keys.toList()
        }
        for (id in idsToLoad) {
            val file = existingFiles[id] ?: continue
            val nativeId = withContext(Dispatchers.IO) { engine.loadSoundFont(file) }
            if (nativeId >= 0) {
                val displayName = index.find { it.first == id }?.second
                    ?: file.name.substringAfter("--", file.name)
                restored.add(SoundFontItem(file.name, displayName, file, nativeId))
            }
        }
        // Also pick up any orphan files not in the index.
        for ((name, file) in existingFiles) {
            if (restored.none { it.id == name }) {
                val nativeId = withContext(Dispatchers.IO) { engine.loadSoundFont(file) }
                if (nativeId >= 0) {
                    restored.add(
                        SoundFontItem(
                            file.name,
                            file.name.substringAfter("--", file.name),
                            file,
                            nativeId
                        )
                    )
                }
            }
        }
        library = restored
        persistLibraryIndex(restored)
        loaded = restored.isNotEmpty()

        val session = withContext(Dispatchers.IO) { readSessionState(context) }
        if (session != null) {
            volume = session.volume
            octave = session.octave
            transpose = session.transpose
            sustain = session.sustain
            bufferFrames = session.bufferFrames
            velocityCurve = session.velocityCurve
            reverbEnabled = session.reverbEnabled
            reverbLevel = session.reverbLevel
            chorusEnabled = session.chorusEnabled
            chorusLevel = session.chorusLevel
            ccMaster = session.ccMaster
            ccSustain = session.ccSustain
            ccTrack1 = session.ccTrack1
            ccTrack2 = session.ccTrack2
            ccTrack3 = session.ccTrack3
            ccTrack4 = session.ccTrack4
            ccTrack5 = session.ccTrack5
            engine.setVolume(volume)
            engine.velocityCurve = velocityCurve
            engine.setBufferFrames(bufferFrames)
            engine.setEffects(reverbEnabled, reverbLevel, chorusEnabled, chorusLevel)
            if (sustain) {
                for (ch in 0 until 5) engine.setSustain(true, ch)
            }
            if (restored.isNotEmpty()) {
                tracks = session.tracks.mapIndexed { i, t ->
                    val font = restored.firstOrNull { it.id == t.soundFontId } ?: restored.first()
                    val count = engine.presetCount(font.nativeId)
                    val preset = if (count > 0) t.presetIndex.coerceIn(0, count - 1) else 0
                    engine.selectPreset(preset, i, font.nativeId)
                    engine.setTrackVolume(i, if (t.enabled) t.volume else 0f)
                    t.copy(soundFontId = font.id, presetIndex = preset, name = "Faixa ${i + 1}")
                }.let { list ->
                    if (list.size >= 5) list.take(5)
                    else list + List(5 - list.size) { i -> TrackState("Faixa ${list.size + i + 1}") }
                }
            }
        } else if (restored.isNotEmpty()) {
            tracks = tracks.mapIndexed { i, t ->
                val font = restored.first()
                val count = engine.presetCount(font.nativeId)
                val preset = if (count > 0) t.presetIndex.coerceIn(0, count - 1) else 0
                engine.selectPreset(preset, i, font.nativeId)
                engine.setTrackVolume(i, if (t.enabled) t.volume else 0f)
                t.copy(soundFontId = font.id, presetIndex = preset)
            }
        }

        engine.ensureAudioRunning()
        if (restored.isNotEmpty()) {
            sf2Name = "${restored.size} SoundFont(s) na biblioteca"
            status = "Biblioteca restaurada: ${restored.size} SoundFont(s)."
        } else {
            status = "Importe um ou mais arquivos .sf2 para a biblioteca."
        }
        sessionRestored = true
    }

    // Persist session when key values change (debounced by composition).
    LaunchedEffect(
        volume, octave, transpose, sustain, bufferFrames, velocityCurve,
        reverbEnabled, reverbLevel, chorusEnabled, chorusLevel, tracks,
        ccMaster, ccSustain, ccTrack1, ccTrack2, ccTrack3, ccTrack4, ccTrack5
    ) {
        if (sessionRestored) persistSession()
    }

    DisposableEffect(Unit) {
        onDispose {
            persistSession()
            persistLibraryIndex(library)
            midiDevices.forEach { try { it.close() } catch (_: Exception) {} }
            engine.close()
        }
    }

    fun refreshMidiDevices() {
        try {
            val manager = context.getSystemService(Context.MIDI_SERVICE) as MidiManager
            midiAvailable = manager.devices.filter { it.outputPortCount > 0 }
            midiStatus = if (midiAvailable.isEmpty()) {
                "Nenhum controlador MIDI detectado"
            } else {
                "Encontrados ${midiAvailable.size} controlador(es)"
            }
        } catch (e: Exception) {
            midiStatus = "Erro ao procurar MIDI: ${e.message}"
        }
    }

    fun connectMidi(info: MidiDeviceInfo) {
        val manager = context.getSystemService(Context.MIDI_SERVICE) as MidiManager
        val mainHandler = android.os.Handler(context.mainLooper)
        val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "Controlador MIDI"
        if (midiNames.contains(name)) {
            midiStatus = "$name já está conectado"
            return
        }
        try {
            manager.openDevice(info, { device ->
                if (device == null) {
                    midiStatus = "Não foi possível abrir $name"
                    return@openDevice
                }
                val port = device.openOutputPort(0)
                if (port == null) {
                    device.close()
                    midiStatus = "Não foi possível abrir a saída de $name"
                    return@openDevice
                }
                try {
                    port.connect(object : MidiReceiver() {
                        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                            if (count < 1) return
                            val st = msg[offset].toInt() and 0xFF
                            val type = st and 0xF0
                            if (count >= 3) {
                                val a = msg[offset + 1].toInt() and 0x7F
                                val b = msg[offset + 2].toInt() and 0x7F
                                when (type) {
                                    0x90 -> for (ch in 0 until 5) {
                                        if (b == 0) {
                                            engine.noteOff((a + octave * 12 + transpose).coerceIn(0, 127), ch)
                                        } else {
                                            engine.noteOn((a + octave * 12 + transpose).coerceIn(0, 127), b, ch)
                                        }
                                    }
                                    0x80 -> for (ch in 0 until 5) {
                                        engine.noteOff((a + octave * 12 + transpose).coerceIn(0, 127), ch)
                                    }
                                    0xB0 -> {
                                        if (a == ccSustain.toIntOrNull()) {
                                            for (ch in 0 until 5) engine.setSustain(b >= 64, ch)
                                            mainHandler.post { sustain = b >= 64 }
                                        }
                                        if (a == ccMaster.toIntOrNull()) {
                                            val v = b / 127f
                                            engine.setVolume(v)
                                            mainHandler.post { volume = v }
                                        }
                                        listOf(ccTrack1, ccTrack2, ccTrack3, ccTrack4, ccTrack5)
                                            .forEachIndexed { i, cc ->
                                                if (a == cc.toIntOrNull()) {
                                                    val v = b / 127f
                                                    mainHandler.post {
                                                        val current = tracks.getOrNull(i)
                                                        if (current != null) {
                                                            tracks = tracks.mapIndexed { j, t ->
                                                                if (j == i) t.copy(volume = v) else t
                                                            }
                                                            engine.setTrackVolume(
                                                                i,
                                                                if (current.enabled) v else 0f
                                                            )
                                                            persistSession()
                                                        }
                                                    }
                                                }
                                            }
                                    }
                                }
                            }
                        }
                    })
                    midiDevices.add(device)
                    midiNames.add(name)
                    midiStatus = "Conectados: ${midiNames.joinToString()}"
                } catch (e: Exception) {
                    try {
                        device.close()
                    } catch (_: Exception) {
                    }
                    midiStatus = "Erro na porta $name: ${e.message}"
                }
            }, android.os.Handler(context.mainLooper))
        } catch (e: Exception) {
            midiStatus = "Erro MIDI: ${e.message}"
        }
    }

    fun disconnectMidi() {
        midiDevices.forEach { try { it.close() } catch (_: Exception) {} }
        midiDevices.clear()
        midiNames.clear()
        midiStatus = "Todos os controladores desconectados"
    }

    fun saveCurrentPreset() {
        val name = newPresetName.trim()
        if (name.isEmpty()) {
            presetMessage = "Digite um nome para o preset."
            return
        }
        if (!loaded) {
            presetMessage = "Carregue um SoundFont antes de salvar."
            return
        }
        val json = JSONObject().apply {
            put("sf2Name", sf2Name)
            put("volume", volume.toDouble())
            put("octave", octave)
            put("transpose", transpose)
            put("sustain", sustain)
            put("midiCc", JSONObject().apply {
                put("master", ccMaster.toIntOrNull() ?: 7)
                put("sustain", ccSustain.toIntOrNull() ?: 64)
                put("track1", ccTrack1.toIntOrNull() ?: 20)
                put("track2", ccTrack2.toIntOrNull() ?: 21)
                put("track3", ccTrack3.toIntOrNull() ?: 22)
                put("track4", ccTrack4.toIntOrNull() ?: 23)
                put("track5", ccTrack5.toIntOrNull() ?: 24)
            })
            val arr = JSONArray()
            tracks.forEach { t ->
                arr.put(
                    JSONObject()
                        .put("id", t.id)
                    .put("soundFontId", t.soundFontId)
                        .put("presetIndex", t.presetIndex)
                        .put("volume", t.volume.toDouble())
                        .put("enabled", t.enabled)
                )
            }
            put("tracks", arr)
        }.toString()
        val updated = (savedPresets.filterNot { it.name.equals(name, ignoreCase = true) } +
            SavedPreset(name, json)).sortedBy { it.name.lowercase() }
        savedPresets = updated
        writeSavedPresets(context, updated)
        newPresetName = ""
        presetMessage = "Preset '$name' salvo."
    }

    fun loadSavedPreset(item: SavedPreset) {
        try {
            if (!loaded || library.isEmpty()) {
                presetMessage = "Importe primeiro os SoundFonts usados nesse preset."
                return
            }
            val obj = JSONObject(item.json)
            val arr = obj.getJSONArray("tracks")
            val newTracks = mutableListOf<TrackState>()
            for (i in 0 until minOf(5, arr.length())) {
                val t = arr.getJSONObject(i)
                val requestedId = t.optString("soundFontId", "")
                val fontId = if (library.any { it.id == requestedId }) requestedId else library.first().id
                newTracks.add(
                    TrackState(
                        name = "Faixa ${i + 1}",
                        soundFontId = fontId,
                        presetIndex = t.optInt("presetIndex", 0),
                        volume = t.optDouble("volume", 0.8).toFloat(),
                        enabled = t.optBoolean("enabled", i == 0)
                    )
                )
            }
            while (newTracks.size < 5) {
                newTracks.add(TrackState("Faixa ${newTracks.size + 1}"))
            }
            volume = obj.optDouble("volume", 0.8).toFloat()
            octave = obj.optInt("octave", 0)
            transpose = obj.optInt("transpose", 0)
            sustain = obj.optBoolean("sustain", false)
            engine.setVolume(volume)
            for (ch in 0 until 5) engine.setSustain(sustain, ch)
            applyTrackSettings(newTracks)
            val cc = obj.optJSONObject("midiCc")
            ccMaster = (cc?.optInt("master", 7) ?: 7).coerceIn(0, 127).toString()
            ccSustain = (cc?.optInt("sustain", 64) ?: 64).coerceIn(0, 127).toString()
            ccTrack1 = (cc?.optInt("track1", 20) ?: 20).coerceIn(0, 127).toString()
            ccTrack2 = (cc?.optInt("track2", 21) ?: 21).coerceIn(0, 127).toString()
            ccTrack3 = (cc?.optInt("track3", 22) ?: 22).coerceIn(0, 127).toString()
            ccTrack4 = (cc?.optInt("track4", 23) ?: 23).coerceIn(0, 127).toString()
            ccTrack5 = (cc?.optInt("track5", 24) ?: 24).coerceIn(0, 127).toString()
            presetMessage = "Preset '${item.name}' carregado, incluindo mapeamentos MIDI CC."
            tab = "Tocar"
            persistSession()
        } catch (e: Exception) {
            presetMessage = "Não foi possível carregar: ${e.message}"
        }
    }

    Column(
        Modifier.fillMaxSize().background(bg).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("SF2 PLAYER", fontSize = 24.sp, fontWeight = FontWeight.Black, color = white)
        Text("FluidSynth • biblioteca SF2 0.9.5 estável", fontSize = 13.sp, color = muted)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Tocar", "Biblioteca", "Instrumentos", "Faixas", "Áudio", "Presets", "MIDI / Diagnóstico")
                .forEach {
                    FilterChip(selected = tab == it, onClick = { tab = it }, label = { Text(it) })
                }
        }

        when (tab) {
            "Tocar" -> Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = panel),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("BIBLIOTECA DE SOUNDFONTS", color = cyan, fontWeight = FontWeight.Bold)
                        Text("${library.size} arquivo(s) armazenado(s)", color = white)
                        Button(
                            onClick = { picker.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Importar SoundFont (.sf2)") }
                        Text(
                            status,
                            color = if (loaded) Color(0xFF86EFAC) else Color(0xFFFBBF24),
                            fontSize = 12.sp
                        )
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = panel),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CONTROLES GERAIS", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Volume master ${(volume * 100).toInt()}%", color = white)
                        Slider(
                            value = volume,
                            onValueChange = {
                                volume = it
                                engine.setVolume(it)
                            }
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Oitava: $octave", color = white)
                            Button(onClick = { octave = (octave - 1).coerceIn(-3, 3) }) { Text("-") }
                            Button(onClick = { octave = (octave + 1).coerceIn(-3, 3) }) { Text("+") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Transposição: $transpose", color = white)
                            Button(onClick = { transpose = (transpose - 1).coerceIn(-12, 12) }) { Text("-") }
                            Button(onClick = { transpose = (transpose + 1).coerceIn(-12, 12) }) { Text("+") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = sustain,
                                onCheckedChange = {
                                    sustain = it
                                    for (ch in 0 until 5) engine.setSustain(it, ch)
                                }
                            )
                            Text("Sustain (pedal)", color = white)
                        }
                    }
                }
                Text(
                    "O teclado virtual foi removido. Conecte um controlador MIDI USB compatível para tocar; os controles, a biblioteca e as faixas continuam disponíveis.",
                    color = muted,
                    fontSize = 12.sp
                )
            }

            "Biblioteca" -> Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "BIBLIOTECA PERMANENTE • ${library.size} SOUNDFONT(S)",
                    color = cyan,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Os arquivos importados ficam guardados no armazenamento privado do aplicativo e sobrevivem ao fechamento. O índice e o estado das faixas são persistidos em SharedPreferences.",
                    color = muted,
                    fontSize = 12.sp
                )
                Button(
                    onClick = { picker.launch(arrayOf("*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Importar arquivo .sf2") }
                if (library.isEmpty()) Text("Nenhum SoundFont importado.", color = muted)
                library.forEach { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(item.name, color = white, fontWeight = FontWeight.Bold)
                                Text(
                                    "${item.file.length() / 1024} KB • ${tracks.count { it.soundFontId == item.id }} faixa(s) usando este arquivo",
                                    color = muted,
                                    fontSize = 11.sp
                                )
                            }
                            OutlinedButton(
                                enabled = tracks.none { it.soundFontId == item.id },
                                onClick = {
                                    if (item.file.delete()) {
                                        library = library.filterNot { it.id == item.id }
                                        persistLibraryIndex(library)
                                        status = "SoundFont removido da biblioteca."
                                        if (library.isEmpty()) {
                                            loaded = false
                                            sf2Name = "Biblioteca vazia"
                                        }
                                        persistSession()
                                    } else {
                                        status = "Não foi possível excluir o arquivo."
                                    }
                                }
                            ) { Text("Excluir") }
                        }
                    }
                }
                Text(status, color = muted, fontSize = 12.sp)
            }

            "Instrumentos" -> Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("INSTRUMENTOS POR FAIXA", color = cyan, fontWeight = FontWeight.Bold)
                Text(
                    "Cada faixa pode usar um SoundFont e um preset diferentes. Altere na aba Faixas os timbres disponíveis no SoundFont escolhido para ela.",
                    color = muted
                )
            }

            "Faixas" -> {
                val landscape =
                    androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
                        Configuration.ORIENTATION_LANDSCAPE
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("MESA DE SOM • 5 FAIXAS", color = cyan, fontWeight = FontWeight.Bold)
                    Text(
                        "Escolha o SoundFont e o timbre de cada faixa independentemente.",
                        color = muted,
                        fontSize = 12.sp
                    )
                    if (library.isEmpty()) Text("Importe arquivos na aba Biblioteca primeiro.", color = white)
                    if (landscape) {
                        Row(
                            Modifier.fillMaxWidth().weight(1f).horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            tracks.forEachIndexed { i, track ->
                                TrackMixerCard(
                                    i, track, library, engine,
                                    onUpdate = { updateTrack(i, it) },
                                    modifier = Modifier.width(245.dp).fillMaxHeight()
                                )
                            }
                        }
                    } else {
                        Column(
                            Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            tracks.forEachIndexed { i, track ->
                                TrackMixerCard(
                                    i, track, library, engine,
                                    onUpdate = { updateTrack(i, it) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }

            "Áudio" -> Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = panel),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("LATÊNCIA / BUFFER", color = cyan, fontWeight = FontWeight.Bold)
                        Text(
                            "Sample rate: ${engine.getSampleRate()} Hz • Buffer: $bufferFrames frames",
                            color = white
                        )
                        Text(
                            "Valores menores = menor latência, maior risco de underrun. Recomendado 128–256 em dispositivos recentes.",
                            color = muted,
                            fontSize = 12.sp
                        )
                        listOf(128, 192, 256, 384, 512, 768, 1024).forEach { f ->
                            FilterChip(
                                selected = bufferFrames == f,
                                onClick = {
                                    bufferFrames = f
                                    engine.setBufferFrames(f)
                                },
                                label = { Text("$f") }
                            )
                        }
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = panel),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CURVA DE VELOCIDADE", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Valor: ${"%.2f".format(velocityCurve)}", color = white)
                        Slider(
                            value = velocityCurve,
                            onValueChange = {
                                velocityCurve = it
                                engine.velocityCurve = it
                            },
                            valueRange = 0.5f..2.0f
                        )
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = panel),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("EFEITOS", color = cyan, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = reverbEnabled,
                                onCheckedChange = {
                                    reverbEnabled = it
                                    engine.setEffects(it, reverbLevel, chorusEnabled, chorusLevel)
                                }
                            )
                            Text("Reverb ${"%.0f".format(reverbLevel * 100)}%", color = white)
                        }
                        Slider(
                            value = reverbLevel,
                            onValueChange = {
                                reverbLevel = it
                                engine.setEffects(reverbEnabled, it, chorusEnabled, chorusLevel)
                            }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = chorusEnabled,
                                onCheckedChange = {
                                    chorusEnabled = it
                                    engine.setEffects(reverbEnabled, reverbLevel, it, chorusLevel)
                                }
                            )
                            Text("Chorus ${"%.1f".format(chorusLevel)}", color = white)
                        }
                        Slider(
                            value = chorusLevel,
                            onValueChange = {
                                chorusLevel = it
                                engine.setEffects(reverbEnabled, reverbLevel, chorusEnabled, it)
                            },
                            valueRange = 0f..5f
                        )
                    }
                }
            }

            "Presets" -> Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("PRESETS DE SESSÃO", color = cyan, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = newPresetName,
                    onValueChange = { newPresetName = it },
                    label = { Text("Nome do preset") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { saveCurrentPreset() },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = loaded
                ) { Text("Salvar preset atual") }
                Text(presetMessage, color = muted, fontSize = 12.sp)
                Text("PRESETS SALVOS (${savedPresets.size})", color = cyan, fontWeight = FontWeight.Bold)
                if (savedPresets.isEmpty()) Text("Nenhum preset salvo ainda.", color = muted)
                savedPresets.forEach { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(item.name, color = white, modifier = Modifier.weight(1f))
                            Button(onClick = { loadSavedPreset(item) }) { Text("Carregar") }
                            OutlinedButton(onClick = {
                                savedPresets = savedPresets.filterNot { it.name == item.name }
                                writeSavedPresets(context, savedPresets)
                            }) { Text("Apagar") }
                        }
                    }
                }
            }

            "MIDI / Diagnóstico" -> Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("MIDI USB", color = cyan, fontWeight = FontWeight.Bold)
                Text(midiStatus, color = white)
                Button(onClick = { refreshMidiDevices() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Procurar controladores")
                }
                midiAvailable.forEach { info ->
                    val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI"
                    Button(
                        onClick = { connectMidi(info) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Conectar: $name") }
                }
                if (midiDevices.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { disconnectMidi() },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Desconectar todos") }
                }
                Text("Mapeamento de CCs MIDI", color = cyan, fontWeight = FontWeight.Bold)
                listOf(
                    "Master volume" to ccMaster,
                    "Sustain" to ccSustain,
                    "Faixa 1" to ccTrack1,
                    "Faixa 2" to ccTrack2,
                    "Faixa 3" to ccTrack3,
                    "Faixa 4" to ccTrack4,
                    "Faixa 5" to ccTrack5
                ).forEachIndexed { idx, (label, value) ->
                    OutlinedTextField(
                        value = value,
                        onValueChange = { v ->
                            val cleaned = v.filter { it.isDigit() }.take(3)
                            when (idx) {
                                0 -> ccMaster = cleaned
                                1 -> ccSustain = cleaned
                                2 -> ccTrack1 = cleaned
                                3 -> ccTrack2 = cleaned
                                4 -> ccTrack3 = cleaned
                                5 -> ccTrack4 = cleaned
                                6 -> ccTrack5 = cleaned
                            }
                        },
                        label = { Text(label) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(
                    "Status motor: ${engine.status}\nBiblioteca: ${library.size} SF2(s)\nSample rate: ${engine.getSampleRate()} Hz",
                    color = muted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun TrackMixerCard(
    index: Int,
    track: TrackState,
    library: List<SoundFontItem>,
    engine: NativeSynth,
    onUpdate: (TrackState) -> Unit,
    modifier: Modifier = Modifier
) {
    val landscape =
        androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
            Configuration.ORIENTATION_LANDSCAPE
    val font = library.firstOrNull { it.id == track.soundFontId }
    val count = font?.let { engine.presetCount(it.nativeId) } ?: 0
    val presetIndex = if (count > 0) track.presetIndex.coerceIn(0, count - 1) else 0
    var soundFontExpanded by remember(index) { mutableStateOf(false) }
    var presetExpanded by remember(index, track.soundFontId) { mutableStateOf(false) }
    val enabled = font != null && engine.loaded

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        if (landscape) {
            Row(
                Modifier.fillMaxSize().padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    Modifier.weight(1f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TrackHeader(index, track, onUpdate, engine)
                    TrackSoundFontSelector(
                        track, library, index, engine, onUpdate,
                        soundFontExpanded, { soundFontExpanded = it }
                    )
                    TrackPresetSelector(
                        track, font, count, presetIndex, index, engine, onUpdate,
                        presetExpanded, { presetExpanded = it }
                    )
                }
                Column(
                    Modifier.width(58.dp).fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        "${(track.volume * 100).toInt()}%",
                        color = white,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(Modifier.width(42.dp).height(154.dp), contentAlignment = Alignment.Center) {
                        Slider(
                            value = track.volume,
                            onValueChange = { v ->
                                onUpdate(track.copy(volume = v))
                                engine.setTrackVolume(index, if (track.enabled) v else 0f)
                            },
                            enabled = enabled,
                            modifier = Modifier.width(146.dp).height(40.dp).rotate(-90f)
                        )
                    }
                    Text("VOLUME", color = muted, fontSize = 9.sp)
                }
            }
        } else {
            Column(
                Modifier.fillMaxWidth().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TrackHeader(index, track, onUpdate, engine)
                TrackSoundFontSelector(
                    track, library, index, engine, onUpdate,
                    soundFontExpanded, { soundFontExpanded = it }
                )
                TrackPresetSelector(
                    track, font, count, presetIndex, index, engine, onUpdate,
                    presetExpanded, { presetExpanded = it }
                )
                Text("Volume: ${(track.volume * 100).toInt()}%", color = white, fontSize = 13.sp)
                Slider(
                    value = track.volume,
                    onValueChange = { v ->
                        onUpdate(track.copy(volume = v))
                        engine.setTrackVolume(index, if (track.enabled) v else 0f)
                    },
                    enabled = enabled
                )
                Text(if (track.enabled) "Ativa" else "Muda", color = muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun TrackHeader(
    index: Int,
    track: TrackState,
    onUpdate: (TrackState) -> Unit,
    engine: NativeSynth
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("FAIXA ${index + 1}", color = cyan, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Switch(
            checked = track.enabled,
            onCheckedChange = {
                onUpdate(track.copy(enabled = it))
                engine.setTrackVolume(index, if (it) track.volume else 0f)
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrackSoundFontSelector(
    track: TrackState,
    library: List<SoundFontItem>,
    index: Int,
    engine: NativeSynth,
    onUpdate: (TrackState) -> Unit,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit
) {
    val font = library.firstOrNull { it.id == track.soundFontId }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = onExpandedChange) {
        OutlinedTextField(
            value = font?.name ?: "Escolher SoundFont",
            onValueChange = {},
            readOnly = true,
            label = { Text("SoundFont") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { onExpandedChange(false) }) {
            library.forEach { item ->
                DropdownMenuItem(
                    text = { Text(item.name) },
                    onClick = {
                        val n = engine.presetCount(item.nativeId)
                        val nextPreset = 0
                        onUpdate(track.copy(soundFontId = item.id, presetIndex = nextPreset))
                        if (n > 0) engine.selectPreset(nextPreset, index, item.nativeId)
                        engine.setTrackVolume(index, if (track.enabled) track.volume else 0f)
                        onExpandedChange(false)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrackPresetSelector(
    track: TrackState,
    font: SoundFontItem?,
    count: Int,
    presetIndex: Int,
    index: Int,
    engine: NativeSynth,
    onUpdate: (TrackState) -> Unit,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit
) {
    if (font != null && count > 0) {
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = onExpandedChange) {
            OutlinedTextField(
                value = engine.presetName(presetIndex, font.nativeId),
                onValueChange = {},
                readOnly = true,
                label = { Text("Timbre") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { onExpandedChange(false) }) {
                (0 until count).forEach { program ->
                    DropdownMenuItem(
                        text = { Text(engine.presetName(program, font.nativeId)) },
                        onClick = {
                            onUpdate(track.copy(presetIndex = program))
                            engine.selectPreset(program, index, font.nativeId)
                            onExpandedChange(false)
                        }
                    )
                }
            }
        }
    } else {
        Text(
            if (font == null) "Escolha um SoundFont." else "Nenhum preset legível.",
            color = muted,
            fontSize = 12.sp
        )
    }
}

/* ---------- Persistence helpers ---------- */

private data class SessionState(
    val volume: Float = 0.8f,
    val octave: Int = 0,
    val transpose: Int = 0,
    val sustain: Boolean = false,
    val bufferFrames: Int = 192,
    val velocityCurve: Float = 1.0f,
    val reverbEnabled: Boolean = true,
    val reverbLevel: Float = 0.35f,
    val chorusEnabled: Boolean = true,
    val chorusLevel: Float = 0.25f,
    val tracks: List<TrackState> = emptyList(),
    val ccMaster: String = "7",
    val ccSustain: String = "64",
    val ccTrack1: String = "20",
    val ccTrack2: String = "21",
    val ccTrack3: String = "22",
    val ccTrack4: String = "23",
    val ccTrack5: String = "24"
)

private fun prefs(context: Context) =
    context.getSharedPreferences("sf2_player", Context.MODE_PRIVATE)

private fun readSavedPresets(context: Context): List<SavedPreset> {
    return try {
        val raw = prefs(context).getString("presets", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            SavedPreset(o.optString("name"), o.optString("json"))
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun writeSavedPresets(context: Context, presets: List<SavedPreset>) {
    val arr = JSONArray()
    presets.forEach { p ->
        arr.put(JSONObject().put("name", p.name).put("json", p.json))
    }
    prefs(context).edit().putString("presets", arr.toString()).apply()
}

/** Persists the ordered list of library entries (id = filename on disk, name = display name). */
private fun writeLibraryIndex(context: Context, items: List<Pair<String, String>>) {
    val arr = JSONArray()
    items.forEach { (id, name) ->
        arr.put(JSONObject().put("id", id).put("name", name))
    }
    prefs(context).edit().putString("library_index", arr.toString()).apply()
}

private fun readLibraryIndex(context: Context): List<Pair<String, String>> {
    return try {
        val raw = prefs(context).getString("library_index", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id")
            if (id.isBlank()) return@mapNotNull null
            id to o.optString("name", id)
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun writeSessionState(context: Context, state: SessionState) {
    try {
        val tracksArr = JSONArray()
        state.tracks.forEach { t ->
            tracksArr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("soundFontId", t.soundFontId)
                    .put("presetIndex", t.presetIndex)
                    .put("volume", t.volume.toDouble())
                    .put("enabled", t.enabled)
            )
        }
        val obj = JSONObject()
            .put("volume", state.volume.toDouble())
            .put("octave", state.octave)
            .put("transpose", state.transpose)
            .put("sustain", state.sustain)
            .put("bufferFrames", state.bufferFrames)
            .put("velocityCurve", state.velocityCurve.toDouble())
            .put("reverbEnabled", state.reverbEnabled)
            .put("reverbLevel", state.reverbLevel.toDouble())
            .put("chorusEnabled", state.chorusEnabled)
            .put("chorusLevel", state.chorusLevel.toDouble())
            .put("tracks", tracksArr)
            .put("ccMaster", state.ccMaster)
            .put("ccSustain", state.ccSustain)
            .put("ccTrack1", state.ccTrack1)
            .put("ccTrack2", state.ccTrack2)
            .put("ccTrack3", state.ccTrack3)
            .put("ccTrack4", state.ccTrack4)
            .put("ccTrack5", state.ccTrack5)
        prefs(context).edit().putString("session_state", obj.toString()).apply()
    } catch (_: Exception) {
    }
}

private fun readSessionState(context: Context): SessionState? {
    return try {
        val raw = prefs(context).getString("session_state", null) ?: return null
        val obj = JSONObject(raw)
        val arr = obj.optJSONArray("tracks") ?: JSONArray()
        val tracks = mutableListOf<TrackState>()
        for (i in 0 until minOf(5, arr.length())) {
            val t = arr.getJSONObject(i)
            tracks.add(
                TrackState(
                    name = "Faixa ${i + 1}",
                    id = "track-${i + 1}",
                    soundFontId = t.optString("soundFontId", ""),
                    presetIndex = t.optInt("presetIndex", 0),
                    volume = t.optDouble("volume", 0.8).toFloat(),
                    enabled = t.optBoolean("enabled", i == 0)
                )
            )
        }
        while (tracks.size < 5) {
            tracks.add(TrackState("Faixa ${tracks.size + 1}", id = "track-${tracks.size + 1}", enabled = tracks.isEmpty()))
        }
        SessionState(
            volume = obj.optDouble("volume", 0.8).toFloat(),
            octave = obj.optInt("octave", 0),
            transpose = obj.optInt("transpose", 0),
            sustain = obj.optBoolean("sustain", false),
            bufferFrames = obj.optInt("bufferFrames", 192).coerceIn(128, 1024),
            velocityCurve = obj.optDouble("velocityCurve", 1.0).toFloat(),
            reverbEnabled = obj.optBoolean("reverbEnabled", true),
            reverbLevel = obj.optDouble("reverbLevel", 0.35).toFloat(),
            chorusEnabled = obj.optBoolean("chorusEnabled", true),
            chorusLevel = obj.optDouble("chorusLevel", 0.25).toFloat(),
            tracks = tracks,
            ccMaster = obj.optString("ccMaster", "7"),
            ccSustain = obj.optString("ccSustain", "64"),
            ccTrack1 = obj.optString("ccTrack1", "20"),
            ccTrack2 = obj.optString("ccTrack2", "21"),
            ccTrack3 = obj.optString("ccTrack3", "22"),
            ccTrack4 = obj.optString("ccTrack4", "23"),
            ccTrack5 = obj.optString("ccTrack5", "24")
        )
    } catch (_: Exception) {
        null
    }
}
