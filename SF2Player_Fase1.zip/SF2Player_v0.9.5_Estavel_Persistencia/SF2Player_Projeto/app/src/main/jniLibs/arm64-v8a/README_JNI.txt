Place libfluidsynth.so (and its dependencies like libglib-2.0.so if needed) here for arm64-v8a.
