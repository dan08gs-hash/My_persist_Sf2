Place FluidSynth public headers (fluidsynth.h and related) in this include/ directory.
