#include <jni.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include <pthread.h>
#include <fluidsynth.h>

static fluid_settings_t *settings = NULL;
static fluid_synth_t *synth = NULL;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static float master_gain = 0.8f;
static float reverb_level = 0.35f;
static float chorus_level = 0.25f;
static int reverb_enabled = 1, chorus_enabled = 1;

static fluid_preset_t *preset_at(fluid_sfont_t *sf, int index) {
    if (!sf || index < 0) return NULL;
    fluid_sfont_iteration_start(sf);
    fluid_preset_t *pr = NULL;
    for (int i = 0; i <= index; i++) {
        pr = fluid_sfont_iteration_next(sf);
        if (!pr) return NULL;
    }
    return pr;
}

JNIEXPORT jint JNICALL Java_br_com_sf2player_NativeSynth_loadNative(JNIEnv *env, jobject thiz, jstring path, jint rate) {
    const char *p = (*env)->GetStringUTFChars(env, path, 0);
    if (!p) return -1;
    pthread_mutex_lock(&lock);
    if (!synth) {
        settings = new_fluid_settings();
        if (settings) {
            fluid_settings_setnum(settings, "synth.sample-rate", (double)rate);
            fluid_settings_setnum(settings, "synth.gain", 0.8);
            fluid_settings_setint(settings, "synth.polyphony", 256);
            fluid_settings_setint(settings, "synth.reverb.active", reverb_enabled);
            fluid_settings_setint(settings, "synth.chorus.active", chorus_enabled);
            synth = new_fluid_synth(settings);
        }
    }
    int id = -1;
    if (synth) {
        id = fluid_synth_sfload(synth, p, 0);
        if (id >= 0) {
            fluid_synth_set_gain(synth, master_gain);
            fluid_synth_set_reverb(synth, 0.45, 0.25, 0.8, reverb_enabled ? reverb_level : 0.0);
            fluid_synth_set_chorus(synth, 3, chorus_enabled ? chorus_level : 0.0, 0.25, 8.0, FLUID_CHORUS_MOD_SINE);
        }
    }
    pthread_mutex_unlock(&lock);
    (*env)->ReleaseStringUTFChars(env, path, p);
    return id;
}

JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_noteOnNative(JNIEnv *e, jobject o, jint ch, jint key, jint vel) {
    pthread_mutex_lock(&lock); if (synth) fluid_synth_noteon(synth, ch, key, vel); pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_noteOffNative(JNIEnv *e, jobject o, jint ch, jint key) {
    pthread_mutex_lock(&lock); if (synth) fluid_synth_noteoff(synth, ch, key); pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_volumeNative(JNIEnv *e, jobject o, jfloat v) {
    pthread_mutex_lock(&lock); master_gain = fmaxf(0.0f, fminf(2.0f, v)); if (synth) fluid_synth_set_gain(synth, master_gain); pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_trackVolumeNative(JNIEnv *e, jobject o, jint ch, jfloat v) {
    pthread_mutex_lock(&lock); if (synth) fluid_synth_cc(synth, ch, 7, (int)(fmaxf(0.f, fminf(1.f, v))*127.f)); pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_renderNative(JNIEnv *e, jobject o, jshortArray arr, jint frames) {
    if (frames <= 0 || frames > 1024) return;
    jsize n = (*e)->GetArrayLength(e, arr);
    if (n < frames * 2) return;
    jshort *out = (*e)->GetShortArrayElements(e, arr, NULL);
    if (!out) return;

    // The Kotlin engine caps block size at 1024 frames. Stack buffers avoid
    // allocating/freeing two native buffers on every real-time audio callback.
    float left[1024];
    float right[1024];
    pthread_mutex_lock(&lock);
    if (synth && fluid_synth_write_float(synth, frames, left, 0, 1, right, 0, 1) == FLUID_OK) {
        for (int i = 0; i < frames; i++) {
            float l = left[i], r = right[i];
            if (l > 1.f) l = 1.f;
            if (l < -1.f) l = -1.f;
            if (r > 1.f) r = 1.f;
            if (r < -1.f) r = -1.f;
            out[i * 2] = (jshort)(l * 32767.f);
            out[i * 2 + 1] = (jshort)(r * 32767.f);
        }
    } else {
        for (int i = 0; i < frames * 2; i++) out[i] = 0;
    }
    pthread_mutex_unlock(&lock);
    (*e)->ReleaseShortArrayElements(e, arr, out, 0);
}

JNIEXPORT jint JNICALL Java_br_com_sf2player_NativeSynth_presetCountNative(JNIEnv *e,jobject o,jint sfid) {
    pthread_mutex_lock(&lock);
    int count=0;
    if (synth) {
        fluid_sfont_t *sf=fluid_synth_get_sfont_by_id(synth, sfid);
        if (sf) { fluid_sfont_iteration_start(sf); while (fluid_sfont_iteration_next(sf) != NULL && count < 4096) count++; }
    }
    pthread_mutex_unlock(&lock); return count;
}
JNIEXPORT jstring JNICALL Java_br_com_sf2player_NativeSynth_presetNameNative(JNIEnv *e,jobject o,jint sfid,jint index) {
    char name[256]="Instrumento";
    pthread_mutex_lock(&lock);
    if (synth) {
        fluid_sfont_t *sf=fluid_synth_get_sfont_by_id(synth, sfid);
        fluid_preset_t *pr=preset_at(sf,index);
        if (pr) { const char *n=fluid_preset_get_name(pr); if(n) snprintf(name,sizeof(name),"%s",n); }
    }
    pthread_mutex_unlock(&lock); return (*e)->NewStringUTF(e,name);
}
JNIEXPORT jboolean JNICALL Java_br_com_sf2player_NativeSynth_selectPresetNative(JNIEnv *e,jobject o,jint ch,jint sfid,jint index) {
    pthread_mutex_lock(&lock);
    int ok=0;
    if (synth && ch>=0 && ch<16) {
        fluid_sfont_t *sf=fluid_synth_get_sfont_by_id(synth,sfid);
        fluid_preset_t *pr=preset_at(sf,index);
        if (pr) ok=(fluid_synth_program_select(synth,ch,sfid,fluid_preset_get_banknum(pr),fluid_preset_get_num(pr))==FLUID_OK);
    }
    pthread_mutex_unlock(&lock); return ok?JNI_TRUE:JNI_FALSE;
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_sustainNative(JNIEnv *e,jobject o,jint ch,jboolean enabled) {
    pthread_mutex_lock(&lock);if(synth)fluid_synth_cc(synth,ch,64,enabled?127:0);pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_setEffectsNative(JNIEnv *e,jobject o,jboolean rev,jfloat rv,jboolean cho,jfloat cv) {
    pthread_mutex_lock(&lock);
    reverb_enabled=rev?1:0; chorus_enabled=cho?1:0;
    reverb_level=fmaxf(0.f,fminf(1.f,rv)); chorus_level=fmaxf(0.f,fminf(10.f,cv));
    if(synth) {
        fluid_synth_set_reverb(synth,0.45,0.25,0.8,reverb_enabled?reverb_level:0.0);
        fluid_synth_set_chorus(synth,3,chorus_enabled?chorus_level:0.0,0.25,8.0,FLUID_CHORUS_MOD_SINE);
    }
    pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_closeNative(JNIEnv *e,jobject o) {
    pthread_mutex_lock(&lock);
    if(synth){delete_fluid_synth(synth);synth=NULL;}
    if(settings){delete_fluid_settings(settings);settings=NULL;}
    pthread_mutex_unlock(&lock);
}
