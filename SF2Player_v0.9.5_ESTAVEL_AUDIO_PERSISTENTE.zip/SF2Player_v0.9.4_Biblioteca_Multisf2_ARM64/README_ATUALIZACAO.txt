SF2 PLAYER - pacote de projeto independente
Versão do pacote: 0.9.5 (baseado no código v0.9.4 Biblioteca Multi-SF2 ARM64)

ARQUIVO ZIP ESPERADO NA RAIZ DO REPOSITÓRIO
SF2Player_v0.9.5_ESTAVEL_AUDIO_PERSISTENTE.zip

MELHORIAS DESTE PACOTE
- Importação de SF2 para armazenamento interno persistente do aplicativo (filesDir/soundfonts).
- Cópia transacional: o arquivo é copiado para um .part e só passa a ser um .sf2 depois de concluída a cópia.
- Validação básica de arquivo vazio/incompleto antes de tentar carregá-lo.
- Limpeza de temporários interrompidos na próxima inicialização.
- Biblioteca reconstruída a partir dos arquivos SF2 válidos presentes no armazenamento interno ao abrir o aplicativo.
- Workflow independente do repositório anterior; nome do ZIP verificado explicitamente.
- Compilação ARM64, Java 17, SDK 36, NDK 27.2.12479018 e Gradle 8.13.

IMPORTANTE SOBRE A PERSISTÊNCIA
Os SoundFonts são guardados no armazenamento interno privado do app. Eles devem sobreviver ao fechamento normal e à reabertura. Desinstalar o aplicativo, limpar os dados/armazenamento do app ou usar um limpador que apague os dados privados remove esses arquivos. A persistência dos arquivos não implica que os mapeamentos de faixas/controles sejam todos restaurados; os presets salvos pela função própria são um recurso separado.

IMPORTANTE SOBRE O ÁUDIO E A COMPILAÇÃO
O código usa FluidSynth através de JNI e AudioTrack em modo streaming. O ZIP de fonte não contém uma biblioteca binária pré-compilada do FluidSynth; o workflow tenta construí-la para ARM64 durante a compilação. A compilação só é considerada bem-sucedida se o APK for realmente gerado e publicado como artefato. O workflow não substitui teste físico de latência, estabilidade, MIDI USB e compatibilidade de SoundFonts no aparelho.

Se a compilação falhar na etapa FluidSynth, use o log dessa etapa para ajustar a receita de compilação da dependência; não considere um APK antigo como resultado da nova compilação.
